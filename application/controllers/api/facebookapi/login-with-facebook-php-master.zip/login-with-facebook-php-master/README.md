# Login with Facebook using PHP
This Repo consists of Skeleton Files required to get started with the implementation of Login With Facebook


**Watch the Login With Facebook Youtube Tutorial on the actual hands-on implementation. Below is the Video Link**


https://www.youtube.com/watch?v=VQmpOKRQnWE
